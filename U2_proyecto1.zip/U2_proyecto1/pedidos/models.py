from django.db import models

class Categoria(models.Model):
    nombre = models.CharField(max_length=80, unique=True)

    class Meta:
        verbose_name_plural = "Categorías"
        ordering = ["nombre"]

    def __str__(self):
        return self.nombre
    
class Producto(models.Model):
    nombre = models.CharField(max_length=120)
    descripcion = models.TextField(null=True)
    precio = models.PositiveIntegerField()
    stock =models.BooleanField(default=False, null=True)
    creado = models.DateTimeField(auto_now_add=True)
    codigo = models.CharField(max_length=20)

    class Meta:
        verbose_name_plural = "Productos"
        ordering = ["nombre"]

        def __str__(self):
            return f"{self.nombre} ${self.producto}"
class cliente(models.Model):
    nombre = models.CharField(max_length=120)
    email= models.EmailField(unique=True)

    class meta:
        verbose_name_plural = "Clientes"
        ordering = ["nombre"]
        
        def __str__(self):
            return f"{self.nombre} {self.email}"
